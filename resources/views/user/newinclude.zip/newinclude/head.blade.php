<head>
        <!-- Meta data -->
        <meta charset="UTF-8">
        <meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
        <meta content="Admitro - Laravel Bootstrap Admin Template" name="description">
        <meta content="Spruko Technologies Private Limited" name="author">
        <meta name="keywords" content="laravel admin dashboard, best laravel admin panel, laravel admin dashboard, php admin panel template, blade template in laravel, laravel dashboard template, laravel template bootstrap, laravel simple admin panel,laravel dashboard template,laravel bootstrap 4 template, best admin panel for laravel,laravel admin panel template, laravel admin dashboard template, laravel bootstrap admin template, laravel admin template bootstrap 4"/>

        <!-- Title -->
        <title>abtyp</title>

        <!--Favicon -->
        <link rel="icon" href="{{url('/')}}/public/images/logo.png" type="image/x-icon"/>

        <!--Bootstrap css -->
        <link href="{{url('/')}}/public/admin/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">

        <!-- Style css -->
        <link href="{{url('/')}}/public/admin/assets/css/style.css" rel="stylesheet" />
        <link href="{{url('/')}}/public/admin/assets/css/style2.css" rel="stylesheet" />
        <link href="{{url('/')}}/public/admin/assets/css/dark.css" rel="stylesheet" />
        <link href="{{url('/')}}/public/admin/assets/css/skin-modes.css" rel="stylesheet" />

        <!-- Animate css -->
        <link href="{{url('/')}}/public/admin/assets/css/animated.css" rel="stylesheet" />

        <!--Sidemenu css -->
       <link href="{{url('/')}}/public/admin/assets/css/sidemenu.css" rel="stylesheet">

        <!-- P-scroll bar css-->
        <link href="{{url('/')}}/public/admin/assets/plugins/p-scrollbar/p-scrollbar.css" rel="stylesheet" />

        <!---Icons css-->
        <link href="{{url('/')}}/public/admin/assets/css/icons.css" rel="stylesheet" />
            
        <!-- Simplebar css -->
        <link rel="stylesheet" href="{{url('/')}}/public/admin/assets/plugins/simplebar/css/simplebar.css">

        <!-- Color Skin css -->
        <link id="theme" href="{{url('/')}}/public/admin/assets/colors/color1.css" rel="stylesheet" type="text/css"/>
        
        <!-- Switcher css -->
        <link rel="stylesheet" href="{{url('/')}}/public/admin/assets/switcher/css/switcher.css">
        <link rel="stylesheet" href="{{url('/')}}/public/admin/assets/switcher/demo.css">


        <!-- Data table css -->
        <link href="{{url('/')}}/public/admin/assets/plugins/datatable/css/dataTables.bootstrap4.min.css" rel="stylesheet" />
        <link href="{{url('/')}}/public/admin/assets/plugins/datatable/css/buttons.bootstrap4.min.css"  rel="stylesheet">
        <link href="{{url('/')}}/public/admin/assets/plugins/datatable/responsive.bootstrap4.min.css" rel="stylesheet" />
        <!-- INTERNAl WYSIWYG Editor css -->
        <link href="{{url('/')}}/public/admin/assets/plugins/wysiwyag/richtext.css" rel="stylesheet" />
        <!-- INTERNAl Quill css -->
        <link href="{{url('/')}}/public/admin/assets/plugins/quill/quill.snow.css" rel="stylesheet">
        <link href="{{url('/')}}/public/admin/assets/plugins/quill/quill.bubble.css" rel="stylesheet">
        
        <script src="https://cdn.ckeditor.com/4.16.1/standard/ckeditor.js"></script>
</head>