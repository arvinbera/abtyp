<aside class="app-sidebar">
    <div class="app-sidebar__logo">
        <a class="header-brand" href="{{url('/admin/dashboard')}}">
          <img src="{{url('/')}}/public/images/logo.png" class="header-brand-img desktop-lgo" alt="Logo">
          <img src="{{url('/')}}/public/images/logo.png" class="header-brand-img dark-logo" alt="Logo">
          <img src="{{url('/')}}/public/images/logo.png" class="header-brand-img mobile-logo" alt="Logo">
          <img src="{{url('/')}}/public/images/logo.png" class="header-brand-img darkmobile-logo" alt="Logo">
        </a>
    </div>
    <!--<div class="app-sidebar__user">
        <div class="dropdown user-pro-body text-center">
            <div class="user-pic">
                <img src="{{url('/')}}/public/admin/assets/images/users/2.jpg" alt="user-img" class="avatar-xl rounded-circle mb-1">
            </div>
            <div class="user-info">
                <h5 class=" mb-1">Jessica <i class="ion-checkmark-circled  text-success fs-12"></i></h5>
                <span class="text-muted app-sidebar__user-name text-sm">Web Designer</span>
            </div>
        </div>
        <div class="sidebar-navs">
          <ul class="nav nav-pills-circle">
            <li class="nav-item" data-placement="top" data-toggle="tooltip" title="Go To Website">
              <a class="icon" target="_blank" href="{{url('/')}}" >
                <i class="las la-life-ring header-icons"></i>
              </a>
            </li>
            <li class="nav-item" data-placement="top" data-toggle="tooltip" title="Documentation">
              <a class="icon" href="#">
                <i class="las  la-file-alt header-icons"></i>
              </a>
            </li>
            <li class="nav-item" data-placement="top" data-toggle="tooltip" title="Projects">
              <a href="#" class="icon">
                <i class="las la-project-diagram header-icons"></i>
              </a>
            </li>
            <li class="nav-item" data-placement="top" data-toggle="tooltip" title="Settins">
              <a class="icon" href="#">
                <i class="las la-cog header-icons"></i>
              </a>
            </li>
          </ul>
        </div>
    </div>-->
    <br>
    <br>
    <ul class="side-menu app-sidebar3">
        <li class="side-item side-item-category mt-4">Main</li>
        <li class="slide">
          	<a class="side-menu__item"  href="{{url('/admin/dashboard')}}">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M19 5v2h-4V5h4M9 5v6H5V5h4m10 8v6h-4v-6h4M9 17v2H5v-2h4M21 3h-8v6h8V3zM11 3H3v10h8V3zm10 8h-8v10h8V11zm-10 4H3v6h8v-6z"/></svg>
            <span class="side-menu__label">Dashboard</span><!-- <span class="badge badge-danger side-badge">Hot</span> --></a>
      	</li>
        <!--<li class="side-item side-item-category">Manage Banner</li>-->
        
        
        
        
        <!--==================================================================New Menu start===============================================================-->
        
        <li class="slide">
							<a class="side-menu__item" data-toggle="slide" href="#">
							<svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M4 8h4V4H4v4zm6 12h4v-4h-4v4zm-6 0h4v-4H4v4zm0-6h4v-4H4v4zm6 0h4v-4h-4v4zm6-10v4h4V4h-4zm-6 4h4V4h-4v4zm6 6h4v-4h-4v4zm0 6h4v-4h-4v4z"/></svg>
							<span class="side-menu__label">Website</span><i class="angle fa fa-angle-right"></i></a>
							<ul class="slide-menu ">
							    <li><a href="{{ route('admin.banner.list') }}" class="slide-item"> Manage Banner</a></li>
							    <li><a href="{{ route('admin.achievement.list') }}" class="slide-item"> Manage Achievement</a></li>
							    <li><a href="{{ route('admin.president.list') }}" class="slide-item"> Manage President</a></li>
							    
								<li class="sub-slide">
									<a class="sub-side-menu__item" data-toggle="sub-slide" href="#"><span class="sub-side-menu__label">Manage History</span><i class="sub-angle fe fe-chevron-down"></i></a>
									<ul class="sub-slide-menu">
										<li><a class="sub-slide-item" href="{{ route('admin.add.terapanth') }}">Terapanth</a></li>
										<li><a class="sub-slide-item" href="{{ route('admin.acharyas.list') }}">Acharyas List</a></li>
										<li><a class="sub-slide-item" href="{{ url('/admin/jainism') }}">Jainism</a></li>
									</ul>
								</li>
								
								
								<li class="sub-slide">
									<a class="sub-side-menu__item" data-toggle="sub-slide" href="#"><span class="sub-side-menu__label">Manage About Us</span><i class="sub-angle fe fe-chevron-down"></i></a>
									<ul class="sub-slide-menu">
										<li><a class="sub-slide-item" href="{{url('/admin/overview')}}">Overview</a></li>
										<li><a class="sub-slide-item" href="{{url('/admin/past-office-bearers')}}">Past office Bearers</a></li>
										<li><a class="sub-slide-item" href="#">Office Bearers – 2019-21</a></li>
										<li><a class="sub-slide-item" href="{{ route('admin.e.w.committee.list') }}">E.W Committee</a></li>
									</ul>
								</li>
								
								
								<li class="sub-slide">
									<a class="sub-side-menu__item" data-toggle="sub-slide" href="#"><span class="sub-side-menu__label">Manage Our Reach</span><i class="sub-angle fe fe-chevron-down"></i></a>
									<ul class="sub-slide-menu">
										<li><a class="sub-slide-item" href="{{url('/admin/parishad-directory')}}">Parishads Directory</a></li>
										<li><a class="sub-slide-item" href="{{url('/admin/members-directory')}}">Members Directory</a></li>
										<li><a class="sub-slide-item" href="{{ route('admin.birthdays.and.anniversaries.list') }}">Birthdays & Anniversaries</a></li>
									</ul>
								</li>
								
								
								<li class="sub-slide">
									<a class="sub-side-menu__item" data-toggle="sub-slide" href="#"><span class="sub-side-menu__label">Manage Our Reach</span><i class="sub-angle fe fe-chevron-down"></i></a>
									<ul class="sub-slide-menu">
										<li><a class="sub-slide-item" href="{{url('/admin/parishad-directory')}}">Parishads Directory</a></li>
										<li><a class="sub-slide-item" href="{{url('/admin/members-directory')}}">Members Directory</a></li>
										<li><a class="sub-slide-item" href="{{ route('admin.birthdays.and.anniversaries.list') }}">Birthdays & Anniversaries</a></li>
									</ul>
								</li>
								
								<li class="sub-slide">
									<a class="sub-side-menu__item" data-toggle="sub-slide" href="#"><span class="sub-side-menu__label">Manage Seva</span><i class="sub-angle fe fe-chevron-down"></i></a>
									<ul class="sub-slide-menu">
										<li><a class="sub-slide-item" href="{{ url('/admin/atdc') }}">ATDC</a></li>
										<li><a class="sub-slide-item" href="{{ url('/admin/eye-donation') }}">Eye Donation </a></li>
										<li><a class="sub-slide-item" href="{{ url('/admin/mbdd') }}">MBDD</a></li>
										<li><a class="sub-slide-item" href="{{ url('/admin/yuva-vahini') }}">YUVA VAHINI</a></li>
									</ul>
								</li>
								
								
								<li class="sub-slide">
									<a class="sub-side-menu__item" data-toggle="sub-slide" href="#"><span class="sub-side-menu__label">Manage Sanskar</span><i class="sub-angle fe fe-chevron-down"></i></a>
									<ul class="sub-slide-menu">
										<li><a class="sub-slide-item" href="{{ url('/admin/barah-vrat') }}">BARAH VRAT</a></li>
										<li><a class="sub-slide-item" href="{{ url('/admin/twenty-five-bol') }}">25 BOL </a></li>
										<li><a class="sub-slide-item" href="{{ url('/admin/confident-public-speaking') }}">Confident Public Speaking</a></li>
										<li><a class="sub-slide-item" href="{{ url('/admin/fit-yuva') }}">FIT YUVA</a></li>
										<li><a class="sub-slide-item" href="{{ url('/admin/jain-sanskar-vidhi') }}">Jain Sanskar Vidhi</a></li>
										<li><a class="sub-slide-item" href="{{ url('/admin/jain-vidhya-karyashala') }}">Jain Vidhya Karyashala</a></li>
										<li><a class="sub-slide-item" href="{{ url('/admin/samayik-sadhak') }}">SAMAYIK SADHAK</a></li>
										<li><a class="sub-slide-item" href="{{ url('/admin/tapoyagya') }}">TAPOYAGYA</a></li>
										<li><a class="sub-slide-item" href="{{ url('/admin/yuva-divas') }}">YUVA DIVAS</a></li>
									</ul>
								</li>
								
								
								<li class="sub-slide">
									<a class="sub-side-menu__item" data-toggle="sub-slide" href="#"><span class="sub-side-menu__label">Manage Sangathan</span><i class="sub-angle fe fe-chevron-down"></i></a>
									<ul class="sub-slide-menu">
										<li><a class="sub-slide-item" href="{{ url('/admin/kishor-mandal') }}">Kishor Mandal</a></li>
										<li><a class="sub-slide-item" href="{{ url('/admin/task-force') }}">Task Force </a></li>
									</ul>
								</li>
								
								<li class="sub-slide">
									<a class="sub-side-menu__item" data-toggle="sub-slide" href="#"><span class="sub-side-menu__label">Manage Media</span><i class="sub-angle fe fe-chevron-down"></i></a>
									<ul class="sub-slide-menu">
										<li><a class="sub-slide-item" href="{{ route('admin.gallery.list') }}">Gallery</a></li>
										<li><a class="sub-slide-item" href="{{ route('admin.vedio.list') }}">Video </a></li>
									</ul>
								</li>
								
								<li><a href="{{ route('admin.downloads.list') }}" class="slide-item">Manage Downloads</a></li>
								
								
								<li class="sub-slide">
									<a class="sub-side-menu__item" data-toggle="sub-slide" href="#"><span class="sub-side-menu__label">Projects & Activities </span><i class="sub-angle fe fe-chevron-down"></i></a>
									<ul class="sub-slide-menu">
										<li><a class="sub-slide-item" href="{{ route('admin.update.seva') }}">Update Seva</a></li>
										<li><a class="sub-slide-item" href="{{ route('admin.update.sanskar') }}">Update Sanskar </a></li>
										<li><a class="sub-slide-item" href="{{ route('admin.update.sangathan') }}">Update Sangathan </a></li>
									</ul>
								</li>
								
									<li><a href="{{ route('admin.get.involved.list') }}" class="slide-item">Get Involved List</a></li>
								
								<li class="sub-slide">
									<a class="sub-side-menu__item" data-toggle="sub-slide" href="#"><span class="sub-side-menu__label">Parkashan</span><i class="sub-angle fe fe-chevron-down"></i></a>
									<ul class="sub-slide-menu">
										<li><a class="sub-slide-item" href="{{ route('admin.update.pathey') }}">Update Pathey</a></li>
										<li><a class="sub-slide-item" href="{{ route('admin.update.terapanth.times') }}">Update Terapanth Times </a></li>
										<li><a class="sub-slide-item" href="{{ route('admin.update.yuva.drishti') }}">Update Yuva Drishti</a></li>
									</ul>
								</li>
								
								
								<li class="sub-slide">
									<a class="sub-side-menu__item" data-toggle="sub-slide" href="#"><span class="sub-side-menu__label">Manage News</span><i class="sub-angle fe fe-chevron-down"></i></a>
									<ul class="sub-slide-menu">
										<li><a class="sub-slide-item" href="{{ route('admin.news.list') }}">Featured News</a></li>
										<li><a class="sub-slide-item" href="{{ route('admin.latest.news.list') }}">Latest News </a></li>
										<li><a class="sub-slide-item" href="{{ route('admin.recent.news.list') }}">Recent News</a></li>
									</ul>
								</li>
								
								<li><a href="{{ route('admin.update.contact') }}" class="slide-item">Update Contact</a></li>
								
								<li><a href="{{url('/admin/welcome-form-list')}}" class="slide-item">Welcome Form List</a></li>
								
								
							</ul>
						</li>
						
						<li class="slide">
                            <a class="side-menu__item" data-toggle="slide" href="index.html#">
                                <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M16.66 4.52l2.83 2.83-2.83 2.83-2.83-2.83 2.83-2.83M9 5v4H5V5h4m10 10v4h-4v-4h4M9 15v4H5v-4h4m7.66-13.31L11 7.34 16.66 13l5.66-5.66-5.66-5.65zM11 3H3v8h8V3zm10 10h-8v8h8v-8zm-10 0H3v8h8v-8z"/></svg>
                                     <span class="side-menu__label">Parishad</span><i class="angle fa fa-angle-right"></i></a>
                                     
                                    <ul class="slide-menu">
                                        <li><a href="{{ route('admin.add-user') }}" class="slide-item">Add Parishad</a></li>
                                    </ul>
                                    
                                    <ul class="slide-menu">
                                        <li><a href="{{ route('admin.user-list') }}" class="slide-item">Parishad List</a></li>
                                    </ul>
                        </li>
                        
                        
                        <li class="slide">
                            <a class="side-menu__item" data-toggle="slide" href="index.html#">
                                <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M16.66 4.52l2.83 2.83-2.83 2.83-2.83-2.83 2.83-2.83M9 5v4H5V5h4m10 10v4h-4v-4h4M9 15v4H5v-4h4m7.66-13.31L11 7.34 16.66 13l5.66-5.66-5.66-5.65zM11 3H3v8h8V3zm10 10h-8v8h8v-8zm-10 0H3v8h8v-8z"/></svg>
                                     <span class="side-menu__label">Member</span><i class="angle fa fa-angle-right"></i></a>
                                     
                                    <ul class="slide-menu">
                                        <li><a href="{{route('admin.pending-yuva-sangam')}}" class="slide-item">Pending Member</a></li>
                                    </ul>
                                    
                                    <ul class="slide-menu">
                                        <li><a href="{{ route('admin.yuva-sangam') }}" class="slide-item">View Member</a></li>
                                    </ul>
                        </li>
                        
                        <li class="slide">
                            <a class="side-menu__item" data-toggle="slide" href="index.html#">
                                <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M16.66 4.52l2.83 2.83-2.83 2.83-2.83-2.83 2.83-2.83M9 5v4H5V5h4m10 10v4h-4v-4h4M9 15v4H5v-4h4m7.66-13.31L11 7.34 16.66 13l5.66-5.66-5.66-5.65zM11 3H3v8h8V3zm10 10h-8v8h8v-8zm-10 0H3v8h8v-8z"/></svg>
                                     <span class="side-menu__label">Monthly Report</span><i class="angle fa fa-angle-right"></i></a>
                                     
                                      <ul class="slide-menu">
                                        <li><a href="{{ route('admin.monthly-report') }}" class="slide-item">View Report</a></li>
                                    </ul>
                                     
                                    <ul class="slide-menu">
                                        <li><a href="{{ route('admin.seva') }}" class="slide-item">Seva</a></li>
                                    </ul>
                                    
                                    <ul class="slide-menu">
                                        <li><a href="{{ route('admin.sanskar') }}" class="slide-item">Sanskar</a></li>
                                    </ul>
                                    
                                    <ul class="slide-menu">
                                        <li><a href="{{ route('admin.sangathan') }}" class="slide-item">Sangathan</a></li>
                                    </ul>
                                    
                                    
                                    <ul class="slide-menu">
                                        <li><a href="{{ route('admin.user-booked-slot') }}" class="slide-item">Booked Slot</a></li>
                                    </ul>
                        </li>
						
						
					
        
        
        
        
        <!--==================================================================New Menu start===============================================================-->
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        <!--<li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="index.html#">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M16.66 4.52l2.83 2.83-2.83 2.83-2.83-2.83 2.83-2.83M9 5v4H5V5h4m10 10v4h-4v-4h4M9 15v4H5v-4h4m7.66-13.31L11 7.34 16.66 13l5.66-5.66-5.66-5.65zM11 3H3v8h8V3zm10 10h-8v8h8v-8zm-10 0H3v8h8v-8z"/></svg>
            <span class="side-menu__label">Manage Banner</span><i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
                <li><a href="{{ route('admin.banner.list') }}" class="slide-item">Banner</a></li>
            </ul>
        </li>-->
        <!--<li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="index.html#">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M16.66 4.52l2.83 2.83-2.83 2.83-2.83-2.83 2.83-2.83M9 5v4H5V5h4m10 10v4h-4v-4h4M9 15v4H5v-4h4m7.66-13.31L11 7.34 16.66 13l5.66-5.66-5.66-5.65zM11 3H3v8h8V3zm10 10h-8v8h8v-8zm-10 0H3v8h8v-8z"/></svg>
            <span class="side-menu__label">Manage History</span><i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
              <li><a href="{{ route('admin.add.terapanth') }}" class="slide-item">Terapanth</a></li>
              <li><a href="{{ route('admin.acharyas.list') }}" class="slide-item">Acharyas List</a></li>
              <li><a href="{{ url('/admin/jainism') }}" class="slide-item">Jainism</a></li>
            </ul>
        </li>-->
        <!--<li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="index.html#">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M16.66 4.52l2.83 2.83-2.83 2.83-2.83-2.83 2.83-2.83M9 5v4H5V5h4m10 10v4h-4v-4h4M9 15v4H5v-4h4m7.66-13.31L11 7.34 16.66 13l5.66-5.66-5.66-5.65zM11 3H3v8h8V3zm10 10h-8v8h8v-8zm-10 0H3v8h8v-8z"/></svg>
            <span class="side-menu__label">Manage About Us</span><i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
              <li><a href="{{url('/admin/overview')}}" class="slide-item">Overview</a></li>
              <li><a href="{{url('/admin/past-office-bearers')}}" class="slide-item">Past office Bearers</a></li>
              <li><a href="#" class="slide-item">Office Bearers – 2019-21</a></li>
              <li><a href="{{ route('admin.e.w.committee.list') }}" class="slide-item">E.W Committee</a></li>
            </ul>
        </li>-->
        <!--<li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="index.html#">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M16.66 4.52l2.83 2.83-2.83 2.83-2.83-2.83 2.83-2.83M9 5v4H5V5h4m10 10v4h-4v-4h4M9 15v4H5v-4h4m7.66-13.31L11 7.34 16.66 13l5.66-5.66-5.66-5.65zM11 3H3v8h8V3zm10 10h-8v8h8v-8zm-10 0H3v8h8v-8z"/></svg>
            <span class="side-menu__label">Manage Our Reach</span><i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
              <li><a href="{{url('/admin/parishad-directory')}}" class="slide-item">Parishads Directory</a></li>
              <li><a href="{{url('/admin/members-directory')}}" class="slide-item">Members Directory</a></li>
              <li><a href="{{ route('admin.birthdays.and.anniversaries.list') }}" class="slide-item">Birthdays & Anniversaries</a></li>
            </ul>
        </li>-->
        <!--<li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="index.html#">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M16.66 4.52l2.83 2.83-2.83 2.83-2.83-2.83 2.83-2.83M9 5v4H5V5h4m10 10v4h-4v-4h4M9 15v4H5v-4h4m7.66-13.31L11 7.34 16.66 13l5.66-5.66-5.66-5.65zM11 3H3v8h8V3zm10 10h-8v8h8v-8zm-10 0H3v8h8v-8z"/></svg>
            <span class="side-menu__label">Manage Seva</span><i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
              <li><a href="{{ url('/admin/atdc') }}" class="slide-item">ATDC</a></li>
              <li><a href="{{ url('/admin/eye-donation') }}" class="slide-item">Eye Donation </a></li>
              <li><a href="{{ url('/admin/mbdd') }}" class="slide-item">MBDD </a></li>
              <li><a href="{{ url('/admin/yuva-vahini') }}" class="slide-item">YUVA VAHINI </a></li>
            </ul>
        </li>
        <li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="index.html#">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M16.66 4.52l2.83 2.83-2.83 2.83-2.83-2.83 2.83-2.83M9 5v4H5V5h4m10 10v4h-4v-4h4M9 15v4H5v-4h4m7.66-13.31L11 7.34 16.66 13l5.66-5.66-5.66-5.65zM11 3H3v8h8V3zm10 10h-8v8h8v-8zm-10 0H3v8h8v-8z"/></svg>
            <span class="side-menu__label">Manage Sanskar</span><i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
              <li><a href="{{ url('/admin/barah-vrat') }}" class="slide-item">BARAH VRAT</a></li>
              <li><a href="{{ url('/admin/twenty-five-bol') }}" class="slide-item">25 BOL</a></li>
              <li><a href="{{ url('/admin/confident-public-speaking') }}" class="slide-item">Confident Public Speaking</a></li>
              <li><a href="{{ url('/admin/fit-yuva') }}" class="slide-item">FIT YUVA</a></li>
              <li><a href="{{ url('/admin/jain-sanskar-vidhi') }}" class="slide-item">Jain Sanskar Vidhi</a></li>
              <li><a href="{{ url('/admin/jain-vidhya-karyashala') }}" class="slide-item">Jain Vidhya Karyashala </a></li>
              <li><a href="{{ url('/admin/samayik-sadhak') }}" class="slide-item">SAMAYIK SADHAK </a></li>
              <li><a href="{{ url('/admin/tapoyagya') }}" class="slide-item">TAPOYAGYA</a></li>
              <li><a href="{{ url('/admin/yuva-divas') }}" class="slide-item">YUVA DIVAS</a></li>
            </ul>
        </li>
        <li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="index.html#">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M16.66 4.52l2.83 2.83-2.83 2.83-2.83-2.83 2.83-2.83M9 5v4H5V5h4m10 10v4h-4v-4h4M9 15v4H5v-4h4m7.66-13.31L11 7.34 16.66 13l5.66-5.66-5.66-5.65zM11 3H3v8h8V3zm10 10h-8v8h8v-8zm-10 0H3v8h8v-8z"/></svg>
            <span class="side-menu__label">Manage Sangathan</span><i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
              <li><a href="{{ url('/admin/kishor-mandal') }}" class="slide-item">Kishor Mandal</a></li>
              <li><a href="{{ url('/admin/task-force') }}" class="slide-item">Task Force </a></li>
            </ul>
        </li>
        <li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="index.html#">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M16.66 4.52l2.83 2.83-2.83 2.83-2.83-2.83 2.83-2.83M9 5v4H5V5h4m10 10v4h-4v-4h4M9 15v4H5v-4h4m7.66-13.31L11 7.34 16.66 13l5.66-5.66-5.66-5.65zM11 3H3v8h8V3zm10 10h-8v8h8v-8zm-10 0H3v8h8v-8z"/></svg>
            <span class="side-menu__label">Manage Media</span><i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
                <li><a href="{{ route('admin.gallery.list') }}" class="slide-item">Gallery </a></li>
                <li><a href="{{ route('admin.vedio.list') }}" class="slide-item">Video </a></li>
            </ul>
        </li>
      	<li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="index.html#">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M16.66 4.52l2.83 2.83-2.83 2.83-2.83-2.83 2.83-2.83M9 5v4H5V5h4m10 10v4h-4v-4h4M9 15v4H5v-4h4m7.66-13.31L11 7.34 16.66 13l5.66-5.66-5.66-5.65zM11 3H3v8h8V3zm10 10h-8v8h8v-8zm-10 0H3v8h8v-8z"/></svg>
            <span class="side-menu__label">Manage Downloads</span><i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
                <li><a href="{{ route('admin.downloads.list') }}" class="slide-item">Downloads </a></li>
            </ul>
        </li>-->
        <!--<li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="index.html#">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M16.66 4.52l2.83 2.83-2.83 2.83-2.83-2.83 2.83-2.83M9 5v4H5V5h4m10 10v4h-4v-4h4M9 15v4H5v-4h4m7.66-13.31L11 7.34 16.66 13l5.66-5.66-5.66-5.65zM11 3H3v8h8V3zm10 10h-8v8h8v-8zm-10 0H3v8h8v-8z"/></svg>
            <span class="side-menu__label">Projects & Activities </span><i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
              <li><a href="{{ route('admin.update.seva') }}" class="slide-item">Update Seva</a></li>
              <li><a href="{{ route('admin.update.sanskar') }}" class="slide-item">Update Sanskar</a></li>
              <li><a href="{{ route('admin.update.sangathan') }}" class="slide-item">Update Sangathan</a></li>
            </ul>
        </li>
        <li class="slide">
              <a class="side-menu__item" data-toggle="slide" href="index.html#">
              <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M16.66 4.52l2.83 2.83-2.83 2.83-2.83-2.83 2.83-2.83M9 5v4H5V5h4m10 10v4h-4v-4h4M9 15v4H5v-4h4m7.66-13.31L11 7.34 16.66 13l5.66-5.66-5.66-5.65zM11 3H3v8h8V3zm10 10h-8v8h8v-8zm-10 0H3v8h8v-8z"/></svg>
              <span class="side-menu__label">Manage Get Involved</span><i class="angle fa fa-angle-right"></i></a>
              <ul class="slide-menu">
                <li><a href="{{ route('admin.get.involved.list') }}" class="slide-item">Get Involved List</a></li>
              </ul>
          </li>
        <li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="index.html#">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M16.66 4.52l2.83 2.83-2.83 2.83-2.83-2.83 2.83-2.83M9 5v4H5V5h4m10 10v4h-4v-4h4M9 15v4H5v-4h4m7.66-13.31L11 7.34 16.66 13l5.66-5.66-5.66-5.65zM11 3H3v8h8V3zm10 10h-8v8h8v-8zm-10 0H3v8h8v-8z"/></svg>
            <span class="side-menu__label">Parkashan</span><i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
              <li><a href="{{ route('admin.update.pathey') }}" class="slide-item">Update Pathey</a></li>
              <li><a href="{{ route('admin.update.terapanth.times') }}" class="slide-item">Update Terapanth Times</a></li>
              <li><a href="{{ route('admin.update.yuva.drishti') }}" class="slide-item">Update Yuva Drishti</a></li>
            </ul>
        </li>
      <li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="index.html#">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M16.66 4.52l2.83 2.83-2.83 2.83-2.83-2.83 2.83-2.83M9 5v4H5V5h4m10 10v4h-4v-4h4M9 15v4H5v-4h4m7.66-13.31L11 7.34 16.66 13l5.66-5.66-5.66-5.65zM11 3H3v8h8V3zm10 10h-8v8h8v-8zm-10 0H3v8h8v-8z"/></svg>
            <span class="side-menu__label">Manage News</span><i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
              <li><a href="{{ route('admin.news.list') }}" class="slide-item">Featured News</a></li>
              <li><a href="{{ route('admin.latest.news.list') }}" class="slide-item">Latest News</a></li>
              <li><a href="{{ route('admin.recent.news.list') }}" class="slide-item">Recent News</a></li>
            </ul>
        </li>
        <li class="slide">
            <a class="side-menu__item" data-toggle="slide" href="index.html#">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M16.66 4.52l2.83 2.83-2.83 2.83-2.83-2.83 2.83-2.83M9 5v4H5V5h4m10 10v4h-4v-4h4M9 15v4H5v-4h4m7.66-13.31L11 7.34 16.66 13l5.66-5.66-5.66-5.65zM11 3H3v8h8V3zm10 10h-8v8h8v-8zm-10 0H3v8h8v-8z"/></svg>
            <span class="side-menu__label">Manage Contact</span><i class="angle fa fa-angle-right"></i></a>
            <ul class="slide-menu">
              <li><a href="{{ route('admin.update.contact') }}" class="slide-item">Update Contact</a></li>
            </ul>
        </li>-->
        
       <!-- <li class="slide">
          	<a class="side-menu__item"  href="{{url('/admin/welcome-form-list')}}">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M19 5v2h-4V5h4M9 5v6H5V5h4m10 8v6h-4v-6h4M9 17v2H5v-2h4M21 3h-8v6h8V3zM11 3H3v10h8V3zm10 8h-8v10h8V11zm-10 4H3v6h8v-6z"/></svg>
            <span class="side-menu__label">Welcome Form List</span></a>
      	</li>-->
      
        
        <!--<li class="slide">
            <a class="side-menu__item"  href="{{ route('admin.seva') }}">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M19 5v2h-4V5h4M9 5v6H5V5h4m10 8v6h-4v-6h4M9 17v2H5v-2h4M21 3h-8v6h8V3zM11 3H3v10h8V3zm10 8h-8v10h8V11zm-10 4H3v6h8v-6z"/></svg>
            <span class="side-menu__label">Seva</span></a>
        </li>
        <li class="slide">
            <a class="side-menu__item"  href="{{ route('admin.sanskar') }}">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M19 5v2h-4V5h4M9 5v6H5V5h4m10 8v6h-4v-6h4M9 17v2H5v-2h4M21 3h-8v6h8V3zM11 3H3v10h8V3zm10 8h-8v10h8V11zm-10 4H3v6h8v-6z"/></svg>
            <span class="side-menu__label">Sanskar</span></a>
        </li>
        <li class="slide">
            <a class="side-menu__item"  href="{{ route('admin.sangathan') }}">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M19 5v2h-4V5h4M9 5v6H5V5h4m10 8v6h-4v-6h4M9 17v2H5v-2h4M21 3h-8v6h8V3zM11 3H3v10h8V3zm10 8h-8v10h8V11zm-10 4H3v6h8v-6z"/></svg>
            <span class="side-menu__label">Sangathan</span></a>
        </li>
        <li class="slide">
            <a class="side-menu__item"  href="{{ route('admin.yuva-sangam') }}">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M19 5v2h-4V5h4M9 5v6H5V5h4m10 8v6h-4v-6h4M9 17v2H5v-2h4M21 3h-8v6h8V3zM11 3H3v10h8V3zm10 8h-8v10h8V11zm-10 4H3v6h8v-6z"/></svg>
            <span class="side-menu__label"> Yuva Sangam</span></a>
        </li>
        <li class="slide">
            <a class="side-menu__item"  href="{{ route('admin.user-booked-slot') }}">
            <svg class="side-menu__icon" xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0V0z" fill="none"/><path d="M19 5v2h-4V5h4M9 5v6H5V5h4m10 8v6h-4v-6h4M9 17v2H5v-2h4M21 3h-8v6h8V3zM11 3H3v10h8V3zm10 8h-8v10h8V11zm-10 4H3v6h8v-6z"/></svg>
            <span class="side-menu__label"> Booked Slot</span></a>
        </li>-->
    </ul>
</aside>