<!--Footer-->
        <footer class="footer">
            <div class="container">
                <div class="row align-items-center flex-row-reverse">
                    <div class="col-md-12 col-sm-12 text-center">
                        Copyright © 2021 <a href="javascript:void(0);">ABTYP</a>. Designed, Built & Maintained By <a class="fl-callout-title-link" href="https://www.eras-tech.com" target="https://www.eras-tech.com">Eras Tech</a> All rights reserved.
                    </div>
                </div>
            </div>
        </footer>
        <!-- End Footer--> 